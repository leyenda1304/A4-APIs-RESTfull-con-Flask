from flask import Flask, render_template, request, redirect, url_for, flash
from models import db
import controllers
from api.routes import api

app = Flask(__name__)

# Configuración de la aplicación
app.config['SECRET_KEY'] = 'clave_local_videojuegos'

# Conexión con MySQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:22MORANbay@localhost/juegos'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar SQLAlchemy
db.init_app(app)

# Registrar las rutas RESTful bajo el prefijo /api
app.register_blueprint(api)


# Página principal: mostrar todos los videojuegos
@app.route("/")
@app.route("/juegos")
def juegos():
    lista_juegos = controllers.obtener_juegos()
    return render_template("juegos.html", juegos=lista_juegos)


# Agregar un videojuego
@app.route("/agregar", methods=["GET", "POST"])
def formulario_agregar_juego():
    if request.method == "POST":
        nombre = request.form["nombre"]
        descripcion = request.form["descripcion"]
        precio = request.form["precio"]

        try:
            controllers.insertar_juego(nombre, descripcion, precio)
            flash("Videojuego agregado correctamente.")
            return redirect(url_for("juegos"))
        except Exception:
            db.session.rollback()
            flash("No se pudo agregar el videojuego. Revisa los datos.")
    
    return render_template("agregar_juego.html")


@app.route("/agregar_juego", methods=["GET", "POST"])
def agregar_juego():
    return formulario_agregar_juego()


# Editar un videojuego
@app.route("/editar", methods=["GET", "POST"])
@app.route("/editar/<int:id>", methods=["GET", "POST"])
def editar_juego(id=None):
    if id is None:
        id = request.args.get("id") or request.form.get("id")

    if not id:
        return redirect(url_for("juegos"))

    juego = controllers.obtener_juego_por_id(id)

    if juego is None:
        flash("No se encontró el videojuego.")
        return redirect(url_for("juegos"))

    if request.method == "POST":
        nombre = request.form["nombre"]
        descripcion = request.form["descripcion"]
        precio = request.form["precio"]

        try:
            controllers.actualizar_juego(nombre, descripcion, precio, id)
            flash("Videojuego actualizado correctamente.")
            return redirect(url_for("juegos"))
        except Exception:
            db.session.rollback()
            flash("No se pudo actualizar el videojuego.")

    return render_template("editar_juego.html", juego=juego)


@app.route("/actualizar_juego", methods=["POST"])
def actualizar_juego():
    id = request.form.get("id")

    if not id:
        return redirect(url_for("juegos"))

    try:
        controllers.actualizar_juego(
            request.form["nombre"],
            request.form["descripcion"],
            request.form["precio"],
            id
        )
        flash("Videojuego actualizado correctamente.")
    except Exception:
        db.session.rollback()
        flash("No se pudo actualizar el videojuego.")

    return redirect(url_for("juegos"))


# Eliminar un videojuego
@app.route("/eliminar", methods=["GET", "POST"])
@app.route("/eliminar_juego", methods=["GET", "POST"])
def eliminar_juego():
    id = request.args.get("id") or request.form.get("id")

    if id:
        try:
            controllers.eliminar_juego(id)
            flash("Videojuego eliminado correctamente.")
        except Exception:
            db.session.rollback()
            flash("No se pudo eliminar el videojuego.")

    return redirect(url_for("juegos"))


# Crear tablas si no existen y ejecutar la aplicación
if __name__ == "__main__":
    with app.app_context():
        from models import Juego
        db.create_all()

    app.run(debug=True, port=8000)
