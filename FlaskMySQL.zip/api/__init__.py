"""Paquete de la API RESTful."""
