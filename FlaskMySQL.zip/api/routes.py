"""
API RESTful de videojuegos.

Endpoints:
GET    /api/juegos       Lista todos los juegos (200).
POST   /api/juegos       Crea un juego (201 + Location).
GET    /api/juegos/<id>  Consulta un juego (200 o 404).
PUT    /api/juegos/<id>  Actualiza un juego (200, 400 o 404).
DELETE /api/juegos/<id>  Elimina un juego (204 o 404).
"""
from decimal import Decimal, InvalidOperation

from flask import Blueprint, jsonify, request, url_for
from models import db, Juego

api = Blueprint("api", __name__, url_prefix="/api")


def juego_a_json(juego):
    """Convierte el modelo Juego a un diccionario compatible con JSON."""
    return {
        "id": juego.id,
        "nombre": juego.nombre,
        "descripcion": juego.descripcion,
        "precio": float(juego.precio),
    }


def validar_datos(data, parcial=False):
    """Valida el JSON de entrada; devuelve (datos, error)."""
    if not isinstance(data, dict):
        return None, "El cuerpo debe ser un objeto JSON."

    permitidos = {"nombre", "descripcion", "precio"}
    desconocidos = set(data.keys()) - permitidos
    if desconocidos:
        return None, "Campos no permitidos: " + ", ".join(sorted(desconocidos))

    resultado = {}
    campos_texto = ("nombre", "descripcion")
    for campo in campos_texto:
        if campo in data:
            valor = data[campo]
            if not isinstance(valor, str) or not valor.strip():
                return None, f"El campo '{campo}' debe ser texto no vacío."
            resultado[campo] = valor.strip()
        elif not parcial:
            return None, f"Falta el campo obligatorio '{campo}'."

    if "precio" in data:
        try:
            precio = Decimal(str(data["precio"]))
            if not precio.is_finite() or precio < 0:
                raise InvalidOperation
            resultado["precio"] = precio
        except (InvalidOperation, ValueError, TypeError):
            return None, "El campo 'precio' debe ser un número mayor o igual a cero."
    elif not parcial:
        return None, "Falta el campo obligatorio 'precio'."

    if parcial and not resultado:
        return None, "Envía al menos un campo para actualizar."
    return resultado, None


@api.get("/juegos")
def listar_juegos():
    """GET /api/juegos: devuelve la colección completa de videojuegos."""
    juegos = Juego.query.order_by(Juego.id.asc()).all()
    return jsonify([juego_a_json(juego) for juego in juegos]), 200


@api.post("/juegos")
def crear_juego():
    """POST /api/juegos: crea un videojuego a partir de JSON."""
    if not request.is_json:
        return jsonify(error="Content-Type debe ser application/json."), 400

    datos, error = validar_datos(request.get_json(silent=True))
    if error:
        return jsonify(error=error), 400

    juego = Juego(
        nombre=datos["nombre"],
        descripcion=datos["descripcion"],
        precio=datos["precio"],
    )
    try:
        db.session.add(juego)
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify(error="No se pudo guardar el videojuego."), 500

    respuesta = jsonify(juego_a_json(juego))
    respuesta.status_code = 201
    respuesta.headers["Location"] = url_for("api.obtener_juego", id=juego.id, _external=False)
    return respuesta


@api.get("/juegos/<int:id>")
def obtener_juego(id):
    """GET /api/juegos/<id>: devuelve un videojuego o 404."""
    juego = db.session.get(Juego, id)
    if juego is None:
        return jsonify(error="Videojuego no encontrado."), 404
    return jsonify(juego_a_json(juego)), 200


@api.put("/juegos/<int:id>")
def actualizar_juego(id):
    """PUT /api/juegos/<id>: actualiza los campos enviados."""
    juego = db.session.get(Juego, id)
    if juego is None:
        return jsonify(error="Videojuego no encontrado."), 404
    if not request.is_json:
        return jsonify(error="Content-Type debe ser application/json."), 400

    datos, error = validar_datos(request.get_json(silent=True), parcial=True)
    if error:
        return jsonify(error=error), 400

    for campo, valor in datos.items():
        setattr(juego, campo, valor)

    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify(error="No se pudo actualizar el videojuego."), 500

    return jsonify(juego_a_json(juego)), 200


@api.delete("/juegos/<int:id>")
def eliminar_juego(id):
    """DELETE /api/juegos/<id>: elimina el recurso y responde sin contenido."""
    juego = db.session.get(Juego, id)
    if juego is None:
        return jsonify(error="Videojuego no encontrado."), 404

    try:
        db.session.delete(juego)
        db.session.commit()
    except Exception:
        db.session.rollback()
        return jsonify(error="No se pudo eliminar el videojuego."), 500

    return "", 204


@api.errorhandler(404)
def ruta_api_no_encontrada(error):
    """Mantiene los errores 404 de rutas API en formato JSON."""
    return jsonify(error="Endpoint o videojuego no encontrado."), 404
