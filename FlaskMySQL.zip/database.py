import pymysql


# Datos de conexión a MySQL
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "22MORANbay",
    "port": 3306,
    "charset": "utf8mb4"
}


def crear_base_datos():
    try:
        # Conectarse a MySQL sin seleccionar una base de datos
        conexion = pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            port=DB_CONFIG["port"],
            charset=DB_CONFIG["charset"]
        )

        cursor = conexion.cursor()

        # Crear la base de datos
        cursor.execute(
            "CREATE DATABASE IF NOT EXISTS juegos "
            "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
        )

        print("Base de datos 'juegos' creada o ya existente.")

        cursor.close()
        conexion.close()

    except pymysql.MySQLError as error:
        print("Error al crear la base de datos:", error)


def crear_tabla():
    try:
        # Conectarse directamente a la base de datos juegos
        conexion = pymysql.connect(
            host=DB_CONFIG["host"],
            user=DB_CONFIG["user"],
            password=DB_CONFIG["password"],
            database="juegos",
            port=DB_CONFIG["port"],
            charset=DB_CONFIG["charset"]
        )

        cursor = conexion.cursor()

        # Crear la tabla de videojuegos
        sql = """
        CREATE TABLE IF NOT EXISTS juegos (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            nombre VARCHAR(255) NOT NULL,
            descripcion VARCHAR(255) NOT NULL,
            precio DECIMAL(9,2) NOT NULL
        )
        """

        cursor.execute(sql)
        conexion.commit()

        print("Tabla 'juegos' creada o ya existente.")

        cursor.close()
        conexion.close()

    except pymysql.MySQLError as error:
        print("Error al crear la tabla:", error)


if __name__ == "__main__":
    crear_base_datos()
    crear_tabla()