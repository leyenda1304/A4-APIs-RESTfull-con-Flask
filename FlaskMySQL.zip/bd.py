import pymysql


def obtener_conexion():
    conexion = pymysql.connect(
        host="localhost",
        user="root",
        password="22MORANbay",
        database="juegos"
    )

    return conexion


if __name__ == "__main__":
    try:
        conexion = obtener_conexion()
        print("Conexión con MySQL realizada correctamente.")
        conexion.close()
    except pymysql.MySQLError as error:
        print("Error de conexión:", error)