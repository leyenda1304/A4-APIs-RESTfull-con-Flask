from bd import obtener_conexion


def insertar_juego(nombre, descripcion, precio):
    conexion = obtener_conexion()

    try:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                INSERT INTO juegos (nombre, descripcion, precio)
                VALUES (%s, %s, %s)
                """,
                (nombre, descripcion, precio)
            )

        conexion.commit()

    finally:
        conexion.close()


def obtener_juegos():
    conexion = obtener_conexion()

    try:
        with conexion.cursor() as cursor:
            cursor.execute(
                "SELECT id, nombre, descripcion, precio FROM juegos"
            )

            return cursor.fetchall()

    finally:
        conexion.close()


def obtener_juego_por_id(id):
    conexion = obtener_conexion()

    try:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                SELECT id, nombre, descripcion, precio
                FROM juegos
                WHERE id = %s
                """,
                (id,)
            )

            return cursor.fetchone()

    finally:
        conexion.close()


def actualizar_juego(nombre, descripcion, precio, id):
    conexion = obtener_conexion()

    try:
        with conexion.cursor() as cursor:
            cursor.execute(
                """
                UPDATE juegos
                SET nombre = %s,
                    descripcion = %s,
                    precio = %s
                WHERE id = %s
                """,
                (nombre, descripcion, precio, id)
            )

        conexion.commit()

    finally:
        conexion.close()


def eliminar_juego(id):
    conexion = obtener_conexion()

    try:
        with conexion.cursor() as cursor:
            cursor.execute(
                "DELETE FROM juegos WHERE id = %s",
                (id,)
            )

        conexion.commit()

    finally:
        conexion.close()