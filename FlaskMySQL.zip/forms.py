from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, EqualTo, Length


# ==============================
# FORMULARIO DE REGISTRO
# ==============================

class RegistrationForm(FlaskForm):

    username = StringField(
        'Nombre de usuario',
        validators=[
            DataRequired(),
            Length(min=4, max=20)
        ]
    )

    password = PasswordField(
        'Contraseña',
        validators=[
            DataRequired(),
            Length(min=6, max=30)
        ]
    )

    confirm_password = PasswordField(
        'Confirmar contraseña',
        validators=[
            DataRequired(),
            EqualTo('password', message='Las contraseñas deben coincidir.')
        ]
    )

    submit = SubmitField('Registrarse')


# ==============================
# FORMULARIO DE LOGIN
# ==============================

class LoginForm(FlaskForm):

    username = StringField(
        'Nombre de usuario',
        validators=[
            DataRequired()
        ]
    )

    password = PasswordField(
        'Contraseña',
        validators=[
            DataRequired()
        ]
    )

    submit = SubmitField('Iniciar sesión')