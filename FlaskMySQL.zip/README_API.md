# Microaplicación de videojuegos + API RESTful

## Requisitos
- Python instalado
- MySQL en ejecución y base de datos `juegos`
- Dependencias: `pip install -r requirements.txt`

## Configuración
La aplicación conserva la configuración local de MySQL que ya tenía el proyecto en `app.py`.
Si tu usuario/contraseña/base de datos son distintos, ajusta `SQLALCHEMY_DATABASE_URI`.

## Ejecutar
Desde esta carpeta:
```bash
python app.py
```
La aplicación escucha en `http://127.0.0.1:8000`.

## API
- `GET /api/juegos` — lista de juegos, 200
- `POST /api/juegos` — crea juego, 201 y cabecera `Location`
- `GET /api/juegos/<id>` — consulta juego, 200 o 404
- `PUT /api/juegos/<id>` — actualiza los campos enviados, 200, 400 o 404
- `DELETE /api/juegos/<id>` — elimina juego, 204 o 404

Los cuerpos JSON usan los campos existentes en el modelo `Juego`: `nombre`, `descripcion`, `precio`.
La API serializa el precio como número JSON y valida los datos entrantes.

## Pruebas
Abre `api_tests.http` con la extensión REST Client de Visual Studio Code y ejecuta cada solicitud. También puedes copiar las solicitudes a Postman.
La aplicación debe poder conectarse a MySQL para que las pruebas de persistencia funcionen.

## Nota
La API se implementó con rutas manuales de Flask y un Blueprint, usando `request`, `jsonify` y SQLAlchemy. No usa Flask-RESTful; esta elección permite comparar el enfoque manual con una extensión de recursos.
